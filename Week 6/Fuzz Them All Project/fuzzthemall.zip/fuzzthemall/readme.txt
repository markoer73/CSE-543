FUZZ THEM ALL Assignment
------------------------

Submitted by: Marco Ermini - mermini@asu.edu
ASU ID: 1222142220

In this assignment I have created a C program that implements the requirements given in terms of accepting the right parameters, using the required seed for random calls, creating additional fuzzing strings, and permutating the strings at every iteration, following the probability of 13% for each character mutation.

The software will initially read the seed file (unless it is piped through STDIN), then quickly go through the permutations required while also adding 10 random characters every 500 iterations. At every iteration, each character is confronted with the 13% probability to be mutated; if the probability is realized, the ASCII value is incremented by one.

By this approach, the string generated is pretty random.  I have then created a Bash shell program that extracts a random seed and then executes the fuzzer in a loop, always passing the current loop cycle counter as the number of iteration to the program. This takes the format of something like the following:

8x---------8x
[...]
start=`date +%s`

prng_seed=$((10000+$RANDOM%1000000))
echo "Using $prng_seed as PRNG seed"

for i in {1..20000}; do
	echo -ne "prng_seed=$prng_seed, iter=$i\r"
	./fuzzer "$prng_seed" "$i" -0 | ./prog_$1 2>/dev/null || {
		status=$?
		if [ "$status" -eq 139 ]; then
			end=`date +%s`
			break
		fi
	}
done
printf "Done $i iterations in %d seconds." $(echo "scale=2;($end-$start)" | bc)
8x---------8x

The previous snippet of the script requires the fuzzer "fuzzer", the program "prog_$1" and the file "seed" to be located under the current directory. (The full script is called "loop.sh" in the project directory).

By running this loop, at a certain point, we will observe the crashing of each of the three programs, terminating with a "Segmentation fault" error.

The programs 0 and 1 crash for me exactly at iteration 4000, while the third needs to go over 6000. 

I have furthermore encountered a certain behavior, by which using certain non-ASCII characters in the fuzzing string, when reaching a certain number of permutations (around 900/1000ish), would cause some of the programs under test to exit with a "Size must be greater than zero." error.  This does not prevent eventually finding, throughout the loop, a certain value that would crash them "properly". To overcome this purely aesthetical behavior, I have created the command line switch "-p" which instructs the program to only use ASCII characters between 32 and 126 (printable).  This effectively solves the issue and makes the error disappear (while still eventually crashing the programs).

Inside every directory of the "test_programs" - "prog0", "prog1", "prog2" - there is a script called "crash_progX" (with "X" standing for 0, 1 or 2).  This will run the fuzzer only once, but using seed and iteration numbers that cause them to crash.

The values that cause the three programs to crash are also located in the home directory of the submission as "crash_progX.txt" (with "X" being again 0, 1, and 2), as required by the assignment.

Prog0:
prng_seed=27771
iter=4000

Prog1:
prng_seed=27771
iter=4000

Prog2:
prng_seed=27771
iter=4000

I was able to also test reliably the first seven of the other test programs. I have used a seed from the other programs, but I have not done more extensive experiments.

$ ./loop_all_prog.sh 
Using 19161 as PRNG seed
Fuzzing prog_0...
./loop_all_prog.sh: line 10: 1727065 Done                    ../fuzzer "$prng_seed" "$i" -0
     1727066 Segmentation fault      | ./prog_$l 2> /dev/null
Program 0 crashed with seed 19161 in 3500 iterations after 11 seconds.
Fuzzing prog_1...
./loop_all_prog.sh: line 10: 1735082 Done                    ../fuzzer "$prng_seed" "$i" -0
     1735083 Segmentation fault      | ./prog_$l 2> /dev/null
Program 1 crashed with seed 19161 in 4000 iterations after 43 seconds.
Fuzzing prog_2...
./loop_all_prog.sh: line 10: 1743221 Done                    ../fuzzer "$prng_seed" "$i" -0
     1743222 Segmentation fault      | ./prog_$l 2> /dev/null
Program 2 crashed with seed 19161 in 4065 iterations after 45 seconds.
Fuzzing prog_3...
./loop_all_prog.sh: line 10: 1770320 Done                    ../fuzzer "$prng_seed" "$i" -0
     1770321 Segmentation fault      | ./prog_$l 2> /dev/null
Program 3 crashed with seed 19161 in 13500 iterations after 302 seconds.
Fuzzing prog_4...
./loop_all_prog.sh: line 10: 1873428 Done                    ../fuzzer "$prng_seed" "$i" -0
     1873429 Segmentation fault      | ./prog_$l 2> /dev/null
Program 4 crashed with seed 19161 in 13000 iterations after 307 seconds.
Fuzzing prog_5...
./loop_all_prog.sh: line 10: 1899659 Done                    ../fuzzer "$prng_seed" "$i" -0
     1899660 Segmentation fault      | ./prog_$l 2> /dev/null
Program 5 crashed with seed 19161 in 13110 iterations after 294 seconds.
Fuzzing prog_6...
./loop_all_prog.sh: line 10: 1903694 Done                    ../fuzzer "$prng_seed" "$i" -0
     1903695 Segmentation fault      | ./prog_$l 2> /dev/null
Program 6 crashed with seed 19161 in 2000 iterations after 76 seconds.
Fuzzing prog_7...
./loop_all_prog.sh: line 10: 1907718 Done                    ../fuzzer "$prng_seed" "$i" -0
     1907719 Segmentation fault      | ./prog_$l 2> /dev/null
Program 7 crashed with seed 19161 in 2000 iterations after 77 seconds.


Dependencies
-----------------
This software is a self-contained C program that does not have special dependencies besides the usual Linux glibc libraries.

This program has been compiled on Kali Linux 5.14.0-kali4-amd64, which is binary compatible with Ubuntu 20.x LTS.  In any case, the source C program "fuzzer.c" is included for recompilation, if required.  The program should be well-through documented.